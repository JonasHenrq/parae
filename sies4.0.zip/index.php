<?php
	header("Location: paginicial.php");
?>