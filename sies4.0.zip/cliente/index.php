<?php
	header("Location: FormularioBuscaCliente.php");
?>