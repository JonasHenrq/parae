	<!DOCTYPE HTML>
	<html>
	<head>
		<title>Cadastrando...</title>
	</head>

	<body>
	<?php
$host = "sql309.gratisphphost.info";
$user = "phpgr_18186479";
$pass = "gd5k6hs1";
$banco = "phpgr_18186479_sies";
	$conn = mysql_connect($host,$user,$pass) or die (mysql_error());
	mysql_select_db($banco) or die(mysql_error());

	$setor = $_POST['setor'];
	$vcarro= $_POST['vcarro'];
	$vmoto = $_POST['vmoto'];
	$sql = mysql_query("INSERT INTO vaga (setor, vcarro, vmoto)
		VALUES ('$setor', '$vcarro', '$vmoto')") or die (mysql_error());
	header("Location: sucesso.php");
	mysql_close();

	?>
	<center><a href="paginicial.php">Voltar</a></center>
	</body>
	</html>