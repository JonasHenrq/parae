<?php
$host = "sql309.gratisphphost.info";
$user = "phpgr_18186479";
$pass = "gd5k6hs1";
$banco = "phpgr_18186479_sies";
$conexao = mysql_connect($host, $user, $pass) or die (mysql_error());
mysql_select_db($banco) or die (mysql_error());
?>

<?php 
	session_start();
	if(!isset($_SESSION["user"]) || !isset($_SESSION["password"])){
		header("Location: login.php");
		exit;
	} else {
		$NomeUser=$_SESSION["user"];
		echo "<center>Olá $NomeUser</center>";
		echo "<center><a href='logout.php'>Sair</a></center>";
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Painel Atendimento</title>
	<link rel="shortcut icon" href="css/imagens/parae.ico" type="image/x-icon" />
</head>
<body>
</br>
<center><h1>Aqui vai ser o painel de Atendimento </h1></center>

</body>
</html>